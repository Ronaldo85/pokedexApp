import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-charmander',
  templateUrl: './charmander.page.html',
  styleUrls: ['./charmander.page.scss'],
})
export class CharmanderPage implements OnInit {

  pokemon = {


  };
  constructor() { }

  ngOnInit() {
  }

}
